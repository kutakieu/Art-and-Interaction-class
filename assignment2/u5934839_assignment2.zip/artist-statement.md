# Artist statement

## Inspiration
I thought it is interesting if paint application has a personality or emotion. Therefore this application move the boxes that is used to change the colour when it gets bored. If user could not click the colour box, this application gets angry and make the lines that user draws noisy. Once the user miss click the box 5 times successively this program starts drawing automatically. This emotion should be frustrating for users but may be able to help users create something they do not expect.
## Method
To draw lines mouseX, mouseY, pmouseX, and pmouseY were used in mouseDragged() method. Noise() method was used to move the colour boxes randomly and naturally instead of random() method.
## Reflection
I am pleased with the move of the colour boxes. If it is implemented with random() method, the move does not look like this application move these boxes. However because there are restrictions in this assignment I could not make this application as if it really has emotion. Therefore, by making the algorithm more complicated this program could be improved. If there is an indicator of this application's emotion, this could be more enjoyable for users.t
